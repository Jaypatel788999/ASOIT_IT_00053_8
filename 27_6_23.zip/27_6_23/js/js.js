let x=10 , y=20;
var z=x+y;
console.log("the sum is=" , z);
var z=x-y;
console.log("the substraction is=" , z);
var z=x*y;
console.log("the multiplication is=" , z);
var z=x/y;
console.log("the division is=" , z);
document.write("the sum is=" , z);
document.write("<br>")
document.write("the substraction is=" , z);
document.write("<br>")
document.write("the multiplication is=" , z);
document.write("<br>")
document.write("the division is=" , z);
document.write("<br>")
var num=100;
var str = "Jay patel";
var boolean = true;
document.write("<br>", typeof(num));
document.write("<br>", typeof(str));
document.write("<br>", typeof(boolean));
var car={
    model: "BMMW X3",
    color: white,
    door:5
}

Document.write()
